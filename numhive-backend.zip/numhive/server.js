const express = require("express"), crypto = require("crypto"), fs = require("fs"), path = require("path");
const { RAZORPAY_KEY_ID: KEY, RAZORPAY_KEY_SECRET: SECRET, RAZORPAY_WEBHOOK_SECRET: WH, ADMIN_KEY, PORT = 3000 } = process.env;
if (!KEY || !SECRET || !WH || !ADMIN_KEY) { console.error("Missing values. Copy .env.example to .env and fill it in."); process.exit(1); }

const PRICES = {
  WhatsApp: { India: 60, USA: 85, UK: 95, Indonesia: 55, Brazil: 70 },
  Telegram: { India: 45, USA: 70, UK: 80, Indonesia: 40, Brazil: 55 }
};

// Simple JSON file storage. Fine for testing; use a real database (Postgres, Supabase) for production.
const FILE = path.join(__dirname, "data.json");
let DB = { users: {}, payments: {}, orders: [] };
try { DB = JSON.parse(fs.readFileSync(FILE, "utf8")); } catch {}
const save = () => fs.writeFileSync(FILE, JSON.stringify(DB, null, 2));

const safeEq = (a, b) => { a = Buffer.from(String(a)); b = Buffer.from(String(b)); return a.length === b.length && crypto.timingSafeEqual(a, b); };
const hmac = (secret, data) => crypto.createHmac("sha256", secret).update(data).digest("hex");
const hashPw = (pw, salt) => crypto.scryptSync(pw, salt, 32).toString("hex");

// The ONLY place credits are added. Idempotent: a payment can be credited once.
function credit(orderId, paymentId, paise) {
  const p = DB.payments[orderId];
  if (!p || p.status === "paid") return false;
  if (p.amount * 100 !== paise) { console.error("Amount mismatch for", orderId); return false; }
  p.status = "paid"; p.paymentId = paymentId; p.paidAt = Date.now();
  DB.users[p.uid].credits += p.amount;
  save();
  return true;
}

const app = express();

// 1) Razorpay webhook: the trusted confirmation. Needs the raw body for the signature check.
app.post("/webhook/razorpay", express.raw({ type: "application/json" }), (req, res) => {
  if (!safeEq(req.get("X-Razorpay-Signature") || "", hmac(WH, req.body))) return res.status(400).end();
  const ev = JSON.parse(req.body.toString());
  if (ev.event === "payment.captured" || ev.event === "order.paid") {
    const pay = ev.payload && ev.payload.payment && ev.payload.payment.entity;
    if (pay) credit(pay.order_id, pay.id, pay.amount);
  }
  res.json({ ok: true });
});

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

const auth = (req, res, next) => {
  const t = (req.get("Authorization") || "").replace("Bearer ", "");
  const u = Object.values(DB.users).find(x => x.token === t);
  if (!t || !u) return res.status(401).json({ error: "Please sign in again" });
  req.user = u; next();
};
const admin = (req, res, next) => safeEq(req.get("x-admin-key") || "", ADMIN_KEY) ? next() : res.status(403).json({ error: "Forbidden" });

app.get("/api/prices", (req, res) => res.json(PRICES));

// Sign in, or create the account if the email is new
app.post("/api/auth", (req, res) => {
  const { name = "", email = "", password = "" } = req.body || {};
  const em = String(email).trim().toLowerCase();
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(em) || String(password).length < 6) return res.status(400).json({ error: "Enter a valid email and a password of 6+ characters" });
  let u = DB.users[em];
  if (u) {
    if (!safeEq(hashPw(password, u.salt), u.hash)) return res.status(401).json({ error: "Wrong password" });
  } else {
    if (!String(name).trim()) return res.status(400).json({ error: "Enter your name to create an account" });
    const salt = crypto.randomBytes(16).toString("hex");
    u = DB.users[em] = { id: em, name: String(name).trim().slice(0, 60), email: em, salt, hash: hashPw(password, salt), credits: 0, token: "" };
  }
  u.token = crypto.randomBytes(24).toString("hex"); save();
  res.json({ token: u.token });
});

app.get("/api/me", auth, (req, res) => {
  const u = req.user;
  res.json({
    user: { name: u.name, email: u.email }, credits: u.credits,
    orders: DB.orders.filter(o => o.uid === u.id).map(o => ({ id: o.id, svc: o.svc, country: o.country, price: o.price, status: o.status, number: o.number })),
    pays: Object.entries(DB.payments).filter(([, p]) => p.uid === u.id).map(([id, p]) => ({ id, amount: p.amount, status: p.status }))
  });
});

// 2) Create a Razorpay order for a top-up
app.post("/api/topup", auth, async (req, res) => {
  const a = Math.floor(Number(req.body && req.body.amount));
  if (!(a >= 50 && a <= 50000)) return res.status(400).json({ error: "Amount must be between ₹50 and ₹50,000" });
  try {
    const r = await fetch("https://api.razorpay.com/v1/orders", {
      method: "POST",
      headers: { Authorization: "Basic " + Buffer.from(KEY + ":" + SECRET).toString("base64"), "Content-Type": "application/json" },
      body: JSON.stringify({ amount: a * 100, currency: "INR", receipt: "nh_" + Date.now() })
    });
    const o = await r.json();
    if (!r.ok) return res.status(502).json({ error: (o.error && o.error.description) || "Could not start payment" });
    DB.payments[o.id] = { uid: req.user.id, amount: a, status: "created", at: Date.now() }; save();
    res.json({ orderId: o.id, amount: o.amount, keyId: KEY });
  } catch { res.status(502).json({ error: "Could not reach Razorpay" }); }
});

// 3) After checkout the browser sends its proof. We re-check the signature before crediting.
app.post("/api/verify", auth, (req, res) => {
  const { razorpay_order_id: oid, razorpay_payment_id: pid, razorpay_signature: sig } = req.body || {};
  const p = DB.payments[oid];
  if (!p || p.uid !== req.user.id) return res.status(404).json({ error: "Unknown payment" });
  if (!safeEq(sig || "", hmac(SECRET, oid + "|" + pid))) return res.status(400).json({ error: "Payment could not be verified" });
  credit(oid, pid, p.amount * 100);
  res.json({ ok: true });
});

app.post("/api/buy", auth, (req, res) => {
  const { service, country } = req.body || {};
  const price = PRICES[service] && PRICES[service][country];
  if (!price) return res.status(400).json({ error: "Unknown item" });
  if (req.user.credits < price) return res.status(400).json({ error: "Not enough credits" });
  req.user.credits -= price;
  DB.orders.push({ id: crypto.randomInt(100000, 999999).toString(), uid: req.user.id, email: req.user.email, svc: service, country, price, status: "Awaiting delivery", number: null, at: Date.now() });
  save(); res.json({ ok: true });
});

// Admin: see paid orders waiting for a number, and deliver
app.get("/admin/orders", admin, (req, res) => res.json(DB.orders.filter(o => o.status !== "Delivered")));
app.post("/admin/deliver", admin, (req, res) => {
  const o = DB.orders.find(x => x.id === (req.body || {}).id);
  const n = String((req.body || {}).number || "").trim().slice(0, 30);
  if (!o || !n) return res.status(400).json({ error: "Missing order or number" });
  o.number = n; o.status = "Delivered"; save(); res.json({ ok: true });
});

app.listen(PORT, () => console.log("NumHive running at http://localhost:" + PORT));
